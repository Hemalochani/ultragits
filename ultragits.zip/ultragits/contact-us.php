
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Digalu - Digital Marketing Agency Template">

    <!-- ========== Page Title ========== -->
    <title>Contact Us | UltraGITS</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="https://www.ultragits.com/assets/img/favicon.png" type="image/x-icon">


    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/elegant-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon-set.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/validnavs.css" rel="stylesheet">
    <link href="assets/css/helper.css" rel="stylesheet">
    <link href="assets/css/unit-test.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <!-- ========== End Stylesheet ========== -->

</head>

<body>

    <!--[if lte IE 9]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
    <![endif]-->


    <!-- Header
    ============================================= -->
    <header>
        <!-- Start Navigation -->

        <?php include 'header.php' ?>
            <!-- Overlay screen for menu -->
            <div class="overlay-screen"></div>
            <!-- End Overlay screen for menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Header -->

     <!-- Start Breadcrumb
    ============================================= -->
    <div class="breadcrumb-area text-center" style=" background-image: url(assets/img/shape/breadcrumb.png); background-color:#e6e6e6;">

        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1>Contact Us</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                            <li class="active">Contact</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->

    <!-- Start Contact Us
    ============================================= -->
    <div class="contact-area default-padding">
        <div class="container">
            <div class="row">
                <div class="col-tact-stye-one col-lg-5 pr-60 pr-md-15 pr-xs-15">
                    <div class="contact-style-one-info">
                        <h2>Contact Information</h2>
                        <p align="justify"><b>Have a question or need support?</b> Our friendly team at UltraGITS is ready to assist you and make your experience effortless and enjoyable.</p>

                        <ul>
                            <li class="wow fadeInUp">
                                <div class="icon">
                                    <i class="fas fa-phone-alt"></i>
                                </div>
                                <div class="content">
                                    <h4 class="title">Call Us</h4>
                                    <a href="tel:8610213611">+91-8610213611</a>
                                    <a href="tel:9600896874">+91-9600896874</a>
                                </div>
                            </li>
                            <li class="wow fadeInUp" data-wow-delay="300ms">
                                <div class="icon">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="info">
                                    <h4 class="title">Head Office - Chennai</h4>
                                    <p>
                                    Faiz Manzil, 10/44, Aziz Mulk 1st St, <br> Thousand Lights, Chennai, Tamil Nadu - 600006
                                    </p>
                                </div>
                            </li>

                            <li class="wow fadeInUp" data-wow-delay="300ms">
                                <div class="icon">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="info">
                                    <h4 class="title">Development Center - Dindigul</h4>
                                    <p>
                                    Above MI Service Centre, 13-13A, Aarthi Theatre Rd <br> Y.M.R. Patty, Karunanidhi Nagar, Dindigul, TN
                                    </p>
                                </div>
                            </li>

                            <li class="wow fadeInUp" data-wow-delay="300ms">
                                <div class="icon">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="info">
                                    <h4 class="title">Registered Office - Arakkonam.</h4>
                                    <p>
                                    #43/35, 2nd Floor, Vedhachalam Street, <br> Arakkonam, Ranipet District, Tamil Nadu - 631001.                         </p>
                                </div>
                            </li>

                            <li class="wow fadeInUp" data-wow-delay="500ms">
                                <div class="icon">
                                    <i class="fas fa-envelope-open-text"></i>
                                </div>
                                <div class="info">
                                    <h4 class="title">Official Email</h4>
                                    <a href="mailto:mail@ultragits.com">mail@ultragits.com</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-tact-stye-one col-lg-7">
                    <div class="contact-form-style-one">
                        <div class="illustration wow fadeInRight" data-wow-delay="300ms">
                            <img src="assets/img/20.png" alt="Image Not Found">
                        </div>
                        <h4 class="sub-heading">Have Questions?</h4>
                        <h2 class="heading">Send us a Massage</h2>
                        <form action="assets/mail/contact.php" method="POST" class="contact-form contact-form">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <input class="form-control" id="name" name="name" placeholder="Name" type="text">
                                        <span class="alert-error"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="email" name="email" placeholder="Email*" type="email">
                                        <span class="alert-error"></span>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="phone" name="phone" placeholder="Phone" type="text">
                                        <span class="alert-error"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group comments">
                                        <textarea class="form-control" id="comments" name="comments" placeholder="Tell Us About Project *"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <button type="submit" name="submit" id="submit" style="background-color: #1e3a74;">
                                        <i class="fa fa-paper-plane"></i> Get in Touch
                                    </button>
                                </div>
                            </div>
                            <!-- Alert Message -->
                            <div class="col-lg-12 alert-notification">
                                <div id="message" class="alert-msg"></div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Contact -->

    <!-- Start Map
    ============================================= -->
    <div class="maps-area bg-gray overflow-hidden">
        <div class="google-maps">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1989982.4023066056!2d80.254787!3d13.055751!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5267244bb8059b%3A0x3b57355810f3ddb9!2sUltraGITS!5e0!3m2!1sen!2sin!4v1744366462726!5m2!1sen!2sin"></iframe>
        </div>
    </div>
    <!-- End Map -->
    <?php include 'footer.php' ?>

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/circle-progress.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/jquery.scrolla.min.js"></script>
    <script src="assets/js/YTPlayer.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/validnavs.js"></script>
    <script src="assets/js/main.js"></script>

</body>
</html>