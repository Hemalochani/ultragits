<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Digalu - Digital Marketing Agency Template">

    <!-- ========== Page Title ========== -->
    <title>Digital Marketing Agency In Chennai - UltraGITS</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="https://www.ultragits.com/assets/img/favicon.png" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/elegant-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon-set.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/validnavs.css" rel="stylesheet">
    <link href="assets/css/helper.css" rel="stylesheet">
    <link href="assets/css/unit-test.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <!-- ========== End Stylesheet ========== -->


</head>

<body>



    <!--[if lte IE 9]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
    <![endif]-->

    <!-- Start Preloader
    ============================================= -->
    <div id="preloader">
        <div id="ambrox-preloader" class="ambrox-preloader">
            <div class="animation-preloader">
                <div class="spinner"></div>
                <div class="txt-loading">
                    <span data-text-preloader="U" class="letters-loading">
                        U
                    </span>
                    <span data-text-preloader="L" class="letters-loading">
                        L
                    </span>
                    <span data-text-preloader="T" class="letters-loading">
                        T
                    </span>
                    <span data-text-preloader="R" class="letters-loading">
                        R
                    </span>
                    <span data-text-preloader="A" class="letters-loading">
                        A
                    </span>
                    <span data-text-preloader="GITS" class="letters-loading">
                        GITS
                    </span>

                </div>
            </div>
            <div class="loader">
                <div class="row">
                    <div class="col-3 loader-section section-left">
                        <div class="bg"></div>
                    </div>
                    <div class="col-3 loader-section section-left">
                        <div class="bg"></div>
                    </div>
                    <div class="col-3 loader-section section-right">
                        <div class="bg"></div>
                    </div>
                    <div class="col-3 loader-section section-right">
                        <div class="bg"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Preloader -->

    <!-- Header
    ============================================= -->
    <header>
        <?php include 'header.php' ?>


    </header>
    <!-- End Header -->

    <?php include 'banner-content.php' ?>
    <!-- Start About
    ============================================= -->
    <div class="about-area circle-shape-right-bottom default-padding">
        <div class="shape-right-center" style="background-image: url(assets/img/shape/20.png);"></div>
        <div class="container">
            <div class="row">

                <div class="col-lg-6">
                    <div class="about-style-four">
                        <div class="thumb">
                            <img src="assets/img/about.svg" alt="Image Not Found">
                            <img src="assets/img/chennai.webp" alt="Image Not Found">

                            <img src="assets/img/icon/chart.png" alt="Image Not Found">
                            <div class="shape">
                                <img src="assets/img/shape/4.png" alt="Image Not Found">
                            </div>
                            <div class="icon">
                                <i class="fas fa-arrow-up"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 pl-60 pl-md-15 pl-xs-15">
                    <div class="about-style-one">
                        <h4 class="sub-heading">About Us</h4>
                        <h2 class="heading">Best Digital Marketting Company In Chennai</h2>
                        <p style="text-align: justify;">
                            UltraGITS is one of the <strong>Best digital marketing agency in chennai</strong> with more than 20+ years of industry experience. Our focus is on providing custom, results-oriented marketing strategies that drive actual & effective business outcomes. We have trained and experienced digital marketers in Chennai, who can make a strategic plan to increase your brand awareness in the world of online. Whether you're a startup aiming for growth or an established business looking to scale up, UltraGITS provides <strong> Digital Marketing Service in Chennai</strong> at affordable cost comparing to other marketing agencies. Want to scale up your business online, contact us to get reliable digital marketing solutions in Chennai.


                        </p>
                        <blockquote>
                            We are a team of seasoned experts with over 20 years of experience in the digital marketing in chennai. We specialize in delivering top-quality IT software and hardware solutions.
                        </blockquote>
                        <a href="https://www.youtube.com/watch?v=owhuBrGIOsE" class="popup-youtube video-play-button with-text">
                            <div class="effect" style="background-color: #1e3a74;"></div>
                            <span><i class="fas fa-play"></i> OUR STORY</span>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End About -->

    <?php include 'services-page.php' ?>
    <?php include 'why-choose-us.php' ?>
    <?php include 'our-expertiese-content.php' ?>

    <?php include 'clients-content.php' ?>
    <?php include 'benifts.php' ?>
    <?php include 'working-process.php' ?>

    <?php include 'testimonial-content.php' ?>
    <?php include 'blog-content.php' ?>

    <?php include 'faq.php' ?>

    <?php include 'footer.php' ?>



    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/circle-progress.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/jquery.scrolla.min.js"></script>
    <script src="assets/js/YTPlayer.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/validnavs.js"></script>
    <script src="assets/js/main.js"></script>

</body>

</html>