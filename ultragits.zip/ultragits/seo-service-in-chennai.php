<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Digalu - Digital Marketing Agency Template">

    <!-- ========== Page Title ========== -->
    <title>Best SEO Service in Chennai With Expert SEO Analyst | UltraGITS</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="https://www.ultragits.com/assets/img/favicon.png" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/elegant-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon-set.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/validnavs.css" rel="stylesheet">
    <link href="assets/css/helper.css" rel="stylesheet">
    <link href="assets/css/unit-test.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <!-- ========== End Stylesheet ========== -->

    <style>
        .hero-section {

            display: flex;
            align-items: center;
            background-color: #f8f9fa;
        }


        .hero-text ul {
            list-style: none;
            padding: 0;
        }

        .hero-text ul li::before {
            content: "✔";
            color: black;
            margin-right: 10px;
        }





@keyframes bounce {
  0%, 20%, 50%, 80%, 100% {
    transform: translateY(0);
  }
  40% {
    transform: translateY(-15px);
  }
  60% {
    transform: translateY(-7px);
  }
}

.icon-animate {
  animation: bounce 2s infinite;
}

/* Extra purple color */
.text-purple {
  color: #6f42c1;
}
p{
    color: black;
     font-size: 18px;

}


.service-card {
  border: none;
  border-radius: 15px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.1);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.service-card:hover {
  transform: translateY(-10px);
  box-shadow: 0 10px 30px rgba(0,0,0,0.2);
}
.icon-wrapper {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto;
  color: #fff;
  font-size: 2rem;
  animation: bounce 2s infinite;
}

/* Bounce animation */
@keyframes bounce {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-10px);
  }
}


.tech-icon {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  padding: 10px;
}
.tech-icon img {
  width: 96px;
  height: 96px;
  animation: float 3s ease-in-out infinite;
}
.tech-icon:hover {
  transform: scale(1.1) rotate(5deg);
}
@keyframes float {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

.animated-icon {
  animation: bounce 2s infinite;
}

@keyframes bounce {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

.counter-box {
  transition: transform 0.3s ease;
}
.counter-box:hover {
  transform: translateY(-5px);
}


.icon-box {
  display: flex;
  flex-direction: column;
  align-items: center;
  animation: zoomIn 2s ease-in-out infinite alternate;
}
.flag-img {
  width: 100px;
  height: auto;
  border-radius: 8px;
  transition: transform 0.5s;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}
.flag-img:hover {
  transform: scale(1.1) rotate(5deg);
}
@keyframes zoomIn {
  from {
    transform: scale(1);
  }
  to {
    transform: scale(1.05);
  }
}


.card-category {
    position: absolute;
    top: 15px;
    right: 15px;
    background-color: #5c768d;
    color: white;
    padding: 5px 15px;
    font-weight: bold;
    text-transform: uppercase;
    font-size: 14px;
    border-radius: 20px;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
}

/* Card Body Styling */
.custom-card .card-body {
    padding: 20px;
}

.card-title {
    font-size: 19px;
    font-weight: bold;

}

.card-text {
    font-size: 18px;
    color: #555;
    margin-bottom: 15px;
}
.custom-card {
    position: relative;
    border: none;
    border-radius: 12px;  /* Rounded corners */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.custom-card:hover {
    transform: translateY(-10px); /* Card lifts on hover */
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2); /* Larger shadow on hover */
}

/* Image Styling: Ensures all images are the same size */
.custom-card img {
    width: 100%; /* Ensure the image takes the full width of the card */
    height: 250px; /* Fixed height for uniformity */
    object-fit: cover; /* Ensures images cover the area without stretching */
}




    </style>
</head>

<body>



    <!-- Header
    ============================================= -->
    <header>
        <?php include 'header.php' ?>


    </header>
    <!-- End Header -->

<!-- Start Breadcrumb
    ============================================= -->
    <div class="breadcrumb-area text-center bg-gray" style="background-image: url(assets/img/shape/breadcrumb.png); background-color:#e6e6e6;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1> SEO Service in Chennai</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                            <li class="active">SEO Service</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->


    <section class="hero-section container-fluid">
        <div class="row w-100 align-items-center">
            <div class="col-lg-6 text-center mb-4 mb-lg-0">
                <img src="assets\img\seo1.png" alt="Business Illustration" class="img-fluid">
            </div>
            <div class="col-lg-6 hero-text px-4"><br>
                <h2><strong>SEO Service in Chennai</strong></h2>
                <p align="justify">We at UltraGITS offer the <b>best SEO service in Chennai</b> at affordable price with great results. We have more than 20+ years of experience in SEO which makes us the best SEO service company in Chennai. Our SEO experts in Chennai employ advanced data driven techniques & strategies to increase the website ranking effectively and increase the look & feel of the website. Our team will work in a proper manner and implement step by step processes like On Pages SEO, Off Page SEO, Technical SEO etc to achieve best ranking in google result page. If you're looking for affordable seo services in Chennai, UltraGITS is your best business partner to grow in the digital world.
</p>


            </div>
        </div>
    </section>


    <br>
<section class="py-5">
  <div class="container text-center">
    <h2 class="mb-5"><strong>Why Choose UltraGITS for SEO Services in Chennai?</strong></h2>
    <div class="row mb-4">
      <!-- Benefit 1 -->
      <div class="col-md-4">
        <div class="p-4">
          <i class="fas fa-briefcase fa-2x mb-3 text-primary icon-animate"></i>
    <h5><strong>20+ Years of Experience in SEO</strong></h5>
          <p>We provide top-quality service with a focus on customer satisfaction and excellence.</p>
        </div>
      </div>

      
      <!-- Benefit 2 -->
      <div class="col-md-4">
        <div class="p-4">
          <i class="fas fa-chart-line fa-2x mb-3 text-success icon-animate"></i>
    <h5><strong>ROI-Focused Strategies Customized for Every Business</strong></h5>
          <p>Our solutions are secure and trusted by thousands of happy clients nationwide.</p>
        </div>
      </div>
      <!-- Benefit 3 -->
      <div class="col-md-4">
        <div class="p-4">
         <i class="fas fa-user-check fa-2x mb-3 text-info icon-animate"></i>
    <h5><strong>Certified and Experienced SEO Specialists in Chennai</strong></h5>
          <p>We offer 24/7 customer support to assist you with any queries or issues you may face.</p>
        </div>
      </div>
    </div>

    <div class="row">
      <!-- Benefit 4 -->
      <div class="col-md-4">
        <div class="p-4">
          <i class="fas fa-trophy fa-2x mb-3 text-warning icon-animate"></i>
    <h5><strong>Best SEO Service Company in Chennai</strong></h5>
          <p>Our team ensures quick delivery to meet your tight deadlines efficiently.</p>
        </div>
      </div>
      <!-- Benefit 5 -->
      <div class="col-md-4">
        <div class="p-4">
         <i class="fas fa-clock fa-2x mb-3 text-danger icon-animate"></i>
    <h5><strong>Real-Time SEO Reporting</strong></h5>
          <p>We provide modern and innovative solutions that drive your business forward.</p>
        </div>
      </div>
      <!-- Benefit 6 -->
      <div class="col-md-4">
        <div class="p-4">
         <i class="fas fa-tags fa-2x mb-3 text-secondary icon-animate"></i>
    <h5><strong>Affordable SEO Services in Chennai with Flexible Packages</strong></h5>
          <p>Our skilled professionals bring deep expertise and experience to every project.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Include Font Awesome CDN (if not already included) -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

<!-- Custom animation + extra color -->



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>



    <section class="py-5" style="background-color: #f8f9fa;">
  <div class="container text-center">
    <h2 class="mb-5" ><strong>Our SEO Services</strong></h2>
    <div class="row mb-4">
      <!-- Service 1 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper bg-primary mb-4">
            <i class="fas fa-search mb-3" style="color: #ffffff; font-size: 2rem;"></i>
            </div>
            <h3 class="card-title"><b>Site Audit</b></h3>
            <p class="card-text">We build custom mobile apps tailored to your business needs, ensuring high performance.</p>
          </div>
        </div>
      </div>
      <!-- Service 2 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper bg-success mb-4">
              <i class="fas fa-key mb-3" style="color: #ffffff; font-size: 2rem;"></i>
            </div>
            <h5 class="card-title"><b>Keyword Analysis</b></h5>
            <p class="card-text">Our cross-platform apps run smoothly on both Android and iOS with one codebase.</p>
          </div>
        </div>
      </div>
      <!-- Service 3 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper bg-warning mb-4">
            <i class="fas fa-link mb-3" style="color: #ffffff; font-size: 2rem;"></i>
            </div>
            <h5 class="card-title"><b>Link Building</b></h5>
            <p class="card-text">Beautiful, user-focused design that enhances user engagement and experience.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <!-- Service 4 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper bg-danger mb-4">
              <i class="fas fa-code mb-3" style="color: #ffffff; font-size: 2rem;"></i>
            </div>
            <h5 class="card-title"><b>On-page SEO</b></h5>
            <p class="card-text">We ensure your app’s data is fully protected with advanced security measures.</p>
          </div>
        </div>
      </div>
      <!-- Service 5 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper bg-info mb-4">
              <i class="fas fa-shield-alt mb-3" style="color: #ffffff; font-size: 2rem;"></i>
            </div>
            <h5 class="card-title"><b>Google Penalty Recovery</b></h5>
            <p class="card-text">We integrate cloud solutions for real-time sync and powerful backend systems.</p>
          </div>
        </div>
      </div>
      <!-- Service 6 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper bg-secondary mb-4">
              <i class="fas fa-globe mb-3" style="color: #ffffff; font-size: 2rem;"></i>
            </div>
            <h5 class="card-title"><b>Local & Global SEO Services</b></h5>
            <p class="card-text">Ongoing support and updates to keep your app running smoothly at all times.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



<section class="hero-section container-fluid" style="background-color: white;">
        <div class="row w-100 align-items-center">
            <div class="col-lg-6 text-center mb-4 mb-lg-0">
                <img src="assets\img\seo2.png" alt="Business Illustration" class="img-fluid">
            </div>
            <div class="col-lg-6 hero-text px-4"><br>
                <h2><strong>Our Expertise in SEO Services in Chennai
</strong></h2>
                <p align="justify">We have a strong experience in SEO when comparing to other service providers in Chennai. With more than 20+ years of experience and 500+ satisfied clients makes us the trusted choice for SEO service in Chennai. We manage international clients in various countries like UAE, UK, USA, Canada, Germany etc, and more than 200+ international clients globally. Whether you're a startup or a well established company looking for SEO services, UltraGITS is your best choice to increase your brand visibility in the world of online. Each business requires a unique strategy that’s why our professional SEO analyst will make a unique strategy to increase the website ranking organically. 
</p>



            </div>
        </div>
    </section>



<div class="container text-center">
  <h2 class="mb-5"><strong>What Sets UltraGITS Apart From Other SEO Companies?</strong></h2>

  <div class="row mb-4">
    <!-- Service 1 -->
    <div class="col-md-6 mb-4">
      <div class="card service-card h-100">
        <div class="card-body">
          <div class="icon-wrapper bg-primary mb-4">
            <i class="fas fa-cogs mb-3" style="color: #ffffff; font-size: 2rem;"></i>
          </div>
          <h3 class="card-title"><b>SEO solution Tailored to You</b></h3>
          <p class="card-text">We don't think one approach works for everyone's business. We build unique SEO strategies that line up with what you want to achieve, whether you're looking to reach people nearby or across the world.</p>
        </div>
      </div>
    </div>

    <!-- Service 2 -->
    <div class="col-md-6 mb-4">
      <div class="card service-card h-100">
        <div class="card-body">
          <div class="icon-wrapper bg-warning mb-4">
            <i class="fas fa-chart-line mb-3" style="color: #ffffff; font-size: 2rem;"></i>
          </div>
          <h5 class="card-title"><b>Clear Process & Up-to-Date Reports</b></h5>
          <p class="card-text">As your SEO team in Chennai, we keep everything open. You'll see how things are going where your keywords ranking, and get technical details throughout the project.</p>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <!-- Service 4 -->
    <div class="col-md-6 mb-4">
      <div class="card service-card h-100">
        <div class="card-body">
          <div class="icon-wrapper bg-danger mb-4">
            <i class="fas fa-check-circle mb-3" style="color: #ffffff; font-size: 2rem;"></i>
          </div>
          <h5 class="card-title"><b>Success Stories and Proven Outcomes</b></h5>
          <p class="card-text">Our SEO work has helped businesses show up higher in searches, get more leads, and turn more visitors into customers. From doctors, property firms to online shops, we created a unique strategy to rank in the first position in SERP.</p>
        </div>
      </div>
    </div>

    <!-- Service 5 -->
    <div class="col-md-6 mb-4">
      <div class="card service-card h-100">
        <div class="card-body">
          <div class="icon-wrapper bg-info mb-4">
            <i class="fas fa-globe mb-3" style="color: #ffffff; font-size: 2rem;"></i>
          </div>
          <h5 class="card-title"><b>SEO for Local and Worldwide Reach</b></h5>
          <p class="card-text">If you need to boost your local search presence or expand into new countries, UltraGITS has the skills and tools to help you rank better wherever your customers are looking.</p>
        </div>
      </div>
    </div>
  </div>
</div>



 <section class="container py-5">
    <div class="row justify-content-center">
        <!-- Left Column (Text Content) -->
        <div class="col-lg-6">
            <h2 class="mb-4 fw-bold text-dark">
                Benefits of Choosing UltraGITS for SEO Service 
            </h2>
            <ul class="list-unstyled fs-5 text-dark">
                <li class="mb-3">✅ Tailored strategies that align with your business goals</li>
                <li class="mb-3">✅ From local SEO to world wide SEO Services</li>
                <li class="mb-3">✅ 500+ trusted Chennai Clients & 200+ Global Clients</li>
                <li class="mb-3">✅ Transparent monthly reports and performance tracking</li>
                <li class="mb-3">✅ Affordable SEO service in Chennai with no hidden charges</li>
                <li class="mb-3">✅ Proven strategies for Local, National, and E-commerce SEO</li>
                <li class="mb-3">✅ Dedicated team of SEO experts in Chennai</li>
                <li class="mb-3">✅ Complete support from planning to optimization</li>
            </ul>
        </div>

        <!-- Right Column (Illustration Image) -->
        <div class="col-lg-6 text-center">
            <img src="assets\img\SEOillustration.png" alt="SEO Illustration" class="img-fluid">
        </div>
    </div>
</section>



<section class="container py-5">
    <div class="row justify-content-center">
        <!-- Left Column (Illustration Image) -->
        <div class="col-lg-6 text-center mb-4 mb-lg-0">
            <img src="assets\img\Seoillustration1.png" alt="SEO Illustration" class="img-fluid">
        </div>

        <!-- Right Column (Text Content) -->
        <div class="col-lg-6">
            <h2 class="mb-4 fw-bold text-dark">
               Industries We Serve with SEO Solutions

            </h2>
            <ul class="list-unstyled fs-5 text-dark">
                <li class="mb-3">✅ Healthcare & Clinics</li>
                <li class="mb-3">✅ Real Estate & Construction</li>
                <li class="mb-3">✅ E-commerce & Retail</li>
                <li class="mb-3">✅ Finance & Banking</li>
                <li class="mb-3">✅ IT & Software Services</li>
                <li class="mb-3">✅ Educational Institutions</li>
                <li class="mb-3">✅ Hotels, Restaurants & Hospitality</li>
                <li class="mb-3">✅ B2B & B2C Companies across various sectors</li>
            </ul>
        </div>
    </div>
</section>






<section class="py-5" style="background-color: #f8f9fa;">
  <div class="container text-center">
    <h2 class="mb-5"><strong>Our Tools Expertise</strong></h2>
    <div class="row justify-content-center">
      <!-- Flutter -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\analytics.png" alt="Google Analytics">
          <p class="mt-3">Google Analytics</p>
        </div>
      </div>
      <!-- Kotlin -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\webmaster.png" alt="Google Webmasters">
          <p class="mt-3">Google Webmasters</p>
        </div>
      </div>
      <!-- Firebase -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\googlemyb.png" alt="Google My Business">
          <p class="mt-3">Google My Business</p>
        </div>
      </div>
      <!-- Angular UI -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\keyword.png" alt="Keyword Planner">
          <p class="mt-3">Keyword Planner</p>
        </div>
      </div>
      <!-- Swift -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\woorank.webp" alt="Woorank">
          <p class="mt-3">Woorank</p>
        </div>
      </div>
      <!-- Onsen UI -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\ubersuggest.webp" alt="Uber Suggest" style="width: 96px; height: 96px;">
          <p class="mt-3">Uber Suggest</p>
        </div>
      </div>
    </div>
  </div>
</section>



<!-- Second Section -->
<?php include 'blog-content.php' ?>
<!-- Font Awesome CDN -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

<?php include 'counter.php' ?>
<!-- Include Font Awesome if not already added -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">


<!-- Counter Animation Script -->
<script>
  const counters = document.querySelectorAll('.counter');
  counters.forEach(counter => {
    counter.innerText = '0';
    const updateCounter = () => {
      const target = +counter.getAttribute('data-target');
      const current = +counter.innerText;
      const increment = target / 200;

      if(current < target) {
        counter.innerText = `${Math.ceil(current + increment)}`;
        setTimeout(updateCounter, 10);
      } else {
        counter.innerText = target;
      }
    };
    updateCounter();
  });
</script>



<section class="py-5 bg" style="background-color: white;">
  <div class="container d-flex align-items-center flex-wrap">
    <!-- Left: Illustration -->
    <div class="col-lg-6 mb-4 mb-lg-0 text-center">
      <img src="assets\img\seo3.png" alt="Illustration" class="img-fluid illustration-animation" style="max-width: 100%;">
    </div>

    <!-- Right: Content -->
    <div class="col-lg-6">
      <h2 class="fw-bold mb-3">Your Vision, Found Online</h2>
      <p class="mb-4">
       We turn your brand into a search engine success story. With tailored SEO strategies and cutting-edge techniques, we help you rise above the noise, reach your audience, and grow with purpose. Let your business shine where it matters most—on page one.
    </p>
      <a href="contact" class="btn btn-primary" style="background-color: #1e3974;">Get Started</a>
    </div>
  </div>
</section>

<!-- Optional Animation -->

<?php include 'flag.php' ?>
 <!-- Start Faq Area
    ============================================= -->
    <div class="faq-area bg-gray default-padding" >
        <!-- Shape -->
        <div class="faq-sahpe">
            <img src="assets/img/illustration/faq1.png" alt="Image Not Found">
            <img src="assets/img/illustration/faq2.png" alt="Image Not Found">
        </div>
        <!-- End Shape -->
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4 class="sub-title">FAQ's</h4>
                        <h2 class="title">Frequently Asked Questions </h2>
                        <div class="devider"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 faq-style-one">

                    <div class="accordion" id="faqAccordion">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                               What makes UltraGITS the best SEO company in Chennai?

                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                    We keep our methods clear, custom-fit, and aimed at results to deliver steady gains and return on investment. 


                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                How long will it take to see SEO results?

                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                    SEO takes time to work. Most sites start to climb in rankings and get more visits in 3–6 months. This depends on how tough the market is, what field you're in, and how healthy your site is working.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                Are your SEO services affordable for small businesses?

                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                    For sure, UltraGITS offers budget-friendly SEO services in Chennai. We cater to new ventures, small and medium firms, and businesses on the rise. We also have flexible plans to match your aims and budget.

                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFour">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                Do you offer eCommerce SEO solutions?

                                </button>
                            </h2>


                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                    Absolutely! We’re an experienced ecommerce SEO agency and have helped numerous online stores improve product rankings, sales, and conversion rates.
                                    </p>
                                </div>
                            </div>
                        </div>



                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFive">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                Will I receive monthly reports?
                                </button>
                            </h2>


                            <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                    Yes We update our client on a daily basis on what work is going on, what is the pending works and how many days the website takes to rank. We will give daily reports that helps you to ensure what is the current status of your website ranking.
                                    </p>
                                </div>
                            </div>
                        </div>





                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingSix">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                               Will I receive monthly reports?
                                </button>
                            </h2>


                            <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                    Yes, we give you in-depth monthly reports that cover traffic stats, keyword rankings, and action plans. You'll also get your own account manager to keep you in the loop.

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End Faq Area -->





    <?php include 'footer.php' ?>



    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/circle-progress.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/jquery.scrolla.min.js"></script>
    <script src="assets/js/YTPlayer.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/validnavs.js"></script>
    <script src="assets/js/main.js"></script>

</body>

</html>