<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Digalu - Digital Marketing Agency Template">

    <!-- ========== Page Title ========== -->
    <title>Affordable Google Ads Service Agency in Chennai | UltraGITS</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="https://www.ultragits.com/assets/img/favicon.png" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/elegant-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon-set.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/validnavs.css" rel="stylesheet">
    <link href="assets/css/helper.css" rel="stylesheet">
    <link href="assets/css/unit-test.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <!-- ========== End Stylesheet ========== -->

    <style>
        .hero-section {

            display: flex;
            align-items: center;
            background-color: #f8f9fa;
        }


        .hero-text ul {
            list-style: none;
            padding: 0;
        }

        .hero-text ul li::before {
            content: "✔";
            color: black;
            margin-right: 10px;
        }





@keyframes bounce {
  0%, 20%, 50%, 80%, 100% {
    transform: translateY(0);
  }
  40% {
    transform: translateY(-15px);
  }
  60% {
    transform: translateY(-7px);
  }
}

.icon-animate {
  animation: bounce 2s infinite;
}

/* Extra purple color */
.text-purple {
  color: #6f42c1;
}
p{
    color: black;
     font-size: 18px;

}


.service-card {
  border: none;
  border-radius: 15px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.1);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.service-card:hover {
  transform: translateY(-10px);
  box-shadow: 0 10px 30px rgba(0,0,0,0.2);
}
.icon-wrapper {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto;
  color: #fff;
  font-size: 2rem;
  animation: bounce 2s infinite;
}

/* Bounce animation */
@keyframes bounce {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-10px);
  }
}


.tech-icon {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  padding: 10px;
}
.tech-icon img {
  width: 96px;
  height: 96px;
  animation: float 3s ease-in-out infinite;
}
.tech-icon:hover {
  transform: scale(1.1) rotate(5deg);
}
@keyframes float {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

.animated-icon {
  animation: bounce 2s infinite;
}

@keyframes bounce {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

.counter-box {
  transition: transform 0.3s ease;
}
.counter-box:hover {
  transform: translateY(-5px);
}


.icon-box {
  display: flex;
  flex-direction: column;
  align-items: center;
  animation: zoomIn 2s ease-in-out infinite alternate;
}
.flag-img {
  width: 100px;
  height: auto;
  border-radius: 8px;
  transition: transform 0.5s;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}
.flag-img:hover {
  transform: scale(1.1) rotate(5deg);
}
@keyframes zoomIn {
  from {
    transform: scale(1);
  }
  to {
    transform: scale(1.05);
  }
}


.card-category {
    position: absolute;
    top: 15px;
    right: 15px;
    background-color: #5c768d;
    color: white;
    padding: 5px 15px;
    font-weight: bold;
    text-transform: uppercase;
    font-size: 14px;
    border-radius: 20px;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
}

/* Card Body Styling */
.custom-card .card-body {
    padding: 20px;
}

.card-title {
    font-size: 19px;
    font-weight: bold;

}

.card-text {
    font-size: 18px;
    color: #555;
    margin-bottom: 15px;
}
.custom-card {
    position: relative;
    border: none;
    border-radius: 12px;  /* Rounded corners */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.custom-card:hover {
    transform: translateY(-10px); /* Card lifts on hover */
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2); /* Larger shadow on hover */
}

/* Image Styling: Ensures all images are the same size */
.custom-card img {
    width: 100%; /* Ensure the image takes the full width of the card */
    height: 250px; /* Fixed height for uniformity */
    object-fit: cover; /* Ensures images cover the area without stretching */
}




    </style>
</head>

<body>



    <!-- Header
    ============================================= -->
    <header>
        <?php include 'header.php' ?>


    </header>
    <!-- End Header -->

<!-- Start Breadcrumb
    ============================================= -->
    <div class="breadcrumb-area text-center bg-gray" style="background-image: url(assets/img/shape/breadcrumb.png); background-color:#e6e6e6;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1>Google Ads Service in Chennai</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                            <li class="active">Google Ads Service</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->


    <section class="hero-section container-fluid">
        <div class="row w-100 align-items-center">
            <div class="col-lg-6 text-center mb-4 mb-lg-0">
                <img src="assets\img\gads3.png" class="img-fluid">
            </div>
            <div class="col-lg-6 hero-text px-4"><br>
                <h2><strong>Google Ads Service in Chennai</strong></h2>
                <p align="justify">UltraGITS offers the best Google ads service in Chennai at affordable price with certified google ads experts. With more than 20+ years of experience and 500+ satisfied clients, makes us the best google ads agency in Chennai. From search ads to shopping ads, We create a unique strategy for each business to reach the highest potential & increase the ROI. Whether you’re a startup or a well established company, We provide best and reliable services to our clients at affordable price when comparing to other vendors. With a deep knowledge of local and global markets, our <b>Google Ads experts </b>create custom campaigns tailored to your business objectives.

</p>
                
            </div>
        </div>
    </section>


    <br>
<section class="py-5">
  <div class="container text-center">
    <h2 class="mb-5"><strong>Why Choose UltraGITS for Google Ads Service in Chennai?</strong></h2>
    <div class="row mb-4">
      <!-- Benefit 1 -->
      <div class="col-md-4">
        <div class="p-4">
          <i class="fas fa-user-clock fa-2x mb-3 text-primary icon-animate"></i>
          <h5><strong>20+ Years of Experience in Google Ads</strong></h5>
          <p>We provide top-quality service with a focus on customer satisfaction and excellence.</p>
        </div>
      </div>
      <!-- Benefit 2 -->
      <div class="col-md-4">
        <div class="p-4">
          <i class="fas fa-certificate fa-2x mb-3 text-success icon-animate"></i>
          <h5><strong>Certified & Experienced Google Ads Specialists</strong></h5>
          <p>Our solutions are secure and trusted by thousands of happy clients nationwide.</p>
        </div>
      </div>
      <!-- Benefit 3 -->
      <div class="col-md-4">
        <div class="p-4">
          <i class="fas fa-chart-line fa-2x mb-3 text-warning icon-animate"></i>
          <h5><strong>ROI-Focused PPC Strategies with Better Conversions</strong></h5>
          <p>We offer 24/7 customer support to assist you with any queries or issues you may face.</p>
        </div>
      </div>
    </div>

    <div class="row">
      <!-- Benefit 4 -->
      <div class="col-md-4">
        <div class="p-4">
          <i class="fas fa-globe fa-2x mb-3 text-danger icon-animate"></i>
          <h5><strong> Custom Campaigns for Local & Global Reach</strong></h5>
          <p>Our team ensures quick delivery to meet your tight deadlines efficiently.</p>
        </div>
      </div>
      <!-- Benefit 5 -->
      <div class="col-md-4">
        <div class="p-4">
          <i class="fas fa-file-alt fa-2x mb-3 text-secondary icon-animate"></i>
          <h5><strong>Daily reporting & Monthly reports</strong></h5>
          <p>We provide modern and innovative solutions that drive your business forward.</p>
        </div>
      </div>
      <!-- Benefit 6 -->
      <div class="col-md-4">
        <div class="p-4">
          <i class="fas fa-tags fa-2x mb-3 text-info icon-animate"></i>
          <h5><strong>Variety of price plans for Google Ads</strong></h5>
          <p>Our skilled professionals bring deep expertise and experience to every project.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Include Font Awesome CDN (if not already included) -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

<!-- Custom animation + extra color -->



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>



    <section class="py-5" style="background-color: #f8f9fa;">
  <div class="container text-center">
    <h2 class="mb-5" ><strong>Our Google Ads Service</strong></h2>
    <div class="row mb-4">
      <!-- Service 1 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper bg-primary mb-4">
              <i class="fab fa-facebook-f mb-3" style="color: #ffffff; font-size: 2rem;"></i>
            </div>
            <h3 class="card-title"><b>Facebook Ads</b></h3>
            <p class="card-text">We build custom mobile apps tailored to your business needs, ensuring high performance.</p>
          </div>
        </div>
      </div>
      <!-- Service 2 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper bg-primary mb-4">
             <i class="fab fa-linkedin-in" style=" color:#ffffff; font-size: 2rem; margin: 0;"></i>



            </div>
            <h5 class="card-title"><b>LinkedIn PPC Ads</b></h5>
            <p class="card-text">Our cross-platform apps run smoothly on both Android and iOS with one codebase.</p>
          </div>
        </div>
      </div>
      <!-- Service 3 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
              <div class="icon-wrapper bg-light mb-4">
              <img src="assets\img\g.png">

            </div>
            <h5 class="card-title"><b>Google SEM Ads</b></h5>
            <p class="card-text">Beautiful, user-focused design that enhances user engagement and experience.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <!-- Service 4 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper bg-danger mb-4">
              <i class="fas fa-sync-alt mb-3" style="color: #ffffff; font-size: 2rem;"></i>
            </div>
            <h5 class="card-title"><b>Ads Remarketing</b></h5>
            <p class="card-text">We ensure your app’s data is fully protected with advanced security measures.</p>
          </div>
        </div>
      </div>
      <!-- Service 5 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper bg-info mb-4">
              <i class="fas fa-mouse-pointer mb-3" style="color: #ffffff; font-size: 2rem;"></i>
            </div>
            <h5 class="card-title"><b>Pay Per Click</b></h5>
            <p class="card-text">We integrate cloud solutions for real-time sync and powerful backend systems.</p>
          </div>
        </div>
      </div>
      <!-- Service 6 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper bg-secondary mb-4">
              <i class="fas fa-search-dollar mb-3" style="color: #ffffff; font-size: 2rem;"></i>
            </div>
            <h5 class="card-title"><b>SEO Marketing</b></h5>
            <p class="card-text">Ongoing support and updates to keep your app running smoothly at all times.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



<section class="hero-section container-fluid" style="background-color: white;">
        <div class="row w-100 align-items-center">
            <div class="col-lg-6 text-center mb-4 mb-lg-0">
                <img src="assets\img\gads1.webp" alt="Business Illustration" class="img-fluid">
            </div>
            <div class="col-lg-6 hero-text px-4"><br>
                <h2><strong>Our Expertise in Google Ads Service
</strong></h2>
                <p align="justify">With an in-depth understanding of local and universal markets, our Google Ads experts develop custom campaigns based on your business needs and objectives, latest trends, and market conditions. We have worked for various kinds of industries such as engineering companies, facility management companies, corporate office sites etc. We conduct market research and look at the data to build a strategy that aligns with your goals, whether that is leads, website traffic or eCommerce sales. We offer Affordable google ads service in Chennai with experienced professionals who have industry experience in the world google ads.
</p>
         </div>
        </div>
    </section>


<div class="container text-center">
  <h2 class="mb-5"><strong>What Sets UltraGITS Apart From Other Google Ads Agencies?</strong></h2>

  <div class="row mb-4">
    <!-- Service 1 -->
    <div class="col-md-6 mb-4">
      <div class="card service-card h-100">
        <div class="card-body">
          <div class="icon-wrapper bg-primary mb-4">
            <i class="fas fa-sliders-h mb-3" style="color: #ffffff; font-size: 2rem;"></i>
          </div>
          <h3 class="card-title"><b>Customized Campaign plans</b></h3>
          <p class="card-text">Every campaign we design is built specifically for your business objectives! Whether you need leads, traffic, engagement, or you want to target locally or globally, we build unique campaigns to your needs.</p>
        </div>
      </div>
    </div>

    <!-- Service 2 -->
    <div class="col-md-6 mb-4">
      <div class="card service-card h-100">
        <div class="card-body">
          <div class="icon-wrapper bg-warning mb-4">
            <i class="fas fa-chart-bar mb-3" style="color: #ffffff; font-size: 2rem;"></i>
          </div>
          <h5 class="card-title"><b>Access to campaign tracking</b></h5>
          <p class="card-text">With UltraGITS you'll get access to how your campaigns perform. We present a clear overview of performance reported as real-time, so you know how your ads are doing at a glance.</p>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <!-- Service 4 -->
    <div class="col-md-6 mb-4">
      <div class="card service-card h-100">
        <div class="card-body">
          <div class="icon-wrapper bg-danger mb-4">
            <i class="fas fa-trophy mb-3" style="color: #ffffff; font-size: 2rem;"></i>
          </div>
          <h5 class="card-title"><b>Successful campaigns</b></h5>
          <p class="card-text">At UltraGITS we've assisted hundreds of businesses in India's, UAE's, UK's, USA's revenue generation through result-driven Google ads. We've worked with small startups to establish national brands with the help of Google Ads.</p>
        </div>
      </div>
    </div>

    <!-- Service 5 -->
    <div class="col-md-6 mb-4">
      <div class="card service-card h-100">
        <div class="card-body">
          <div class="icon-wrapper bg-info mb-4">
            <i class="fas fa-bullhorn mb-3" style="color: #ffffff; font-size: 2rem;"></i>
          </div>
          <h5 class="card-title"><b>We do all forms of ads</b></h5>
          <p class="card-text">Our ad services include everything from search ads, display ads, YouTube ads to shopping ads services. Whether you're a B2B or B2C business, we have a productive ad strategy on hand to improve your ROI.</p>
        </div>
      </div>
    </div>
  </div>
</div>



 <section class="container py-5">
    <div class="row justify-content-center">
        <!-- Left Column (Text Content) -->
        <div class="col-lg-6">
            <h2 class="mb-4 fw-bold text-dark">
                Benefits of Choosing UltraGITS for Google Ads Service  
            </h2>
            <ul class="list-unstyled fs-5 text-dark">
                <li class="mb-3">✅ Certified Google Ads Agency in Chennai</li>
                <li class="mb-3">✅ Complete PPC Campaign Management</li>
                <li class="mb-3">✅ Affordable Google Ads Service with High ROI</li>
                <li class="mb-3">✅ Advanced ecommerce google ads service<</li>
                <li class="mb-3">✅ 500+ Happy Clients Across India & Abroad</li>
                <li class="mb-3">✅ Transparent Billing & No Hidden Charges</li>
                <li class="mb-3">✅ Ongoing Optimization & Daily Monitoring</li>
                <li class="mb-3">✅ Local & Global Campaign Support</li>
            </ul>
        </div>

        <!-- Right Column (Illustration Image) -->
        <div class="col-lg-6 text-center">
            <img src="assets\img\googleads.png" alt="Google Ads Illustration" class="img-fluid">
        </div>
    </div>
</section>



<section class="container py-5">
    <div class="row justify-content-center">
        <!-- Left Column (Illustration Image) -->
        <div class="col-lg-6 text-center mb-4 mb-lg-0">
            <img src="assets\img\googleads1.png" alt="Google Ads Illustration" class="img-fluid">
        </div>

        <!-- Right Column (Text Content) -->
        <div class="col-lg-6">
            <h2 class="mb-4 fw-bold text-dark">
               Industries We Serve with Google Ads Solutions

            </h2>
            <ul class="list-unstyled fs-5 text-dark">
                <li class="mb-3">✅ E-commerce & Online Retail</li>
                <li class="mb-3">✅ Real Estate & Builders</li>
                <li class="mb-3">✅ Healthcare & Clinics</li>
                <li class="mb-3">✅ Educational Institutions</li>
                <li class="mb-3">✅ Finance & Banking</li>
                <li class="mb-3">✅ IT & Software Services</li>
                <li class="mb-3">✅ Hospitality & Travel</li>
                <li class="mb-3">✅ Automotive, Legal, & B2B Services</li>
            </ul>
        </div>
    </div>
</section>



<section class="py-5" style="background-color: #f8f9fa;">
  <div class="container text-center">
    <h2 class="mb-5"><strong>Our Tools Expertise</strong></h2>
    <div class="row justify-content-center">
      <!-- Flutter -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\keywordtool.png" alt="Keyword Tool">
          <p class="mt-3">Keyword Tool</p>
        </div>
      </div>
      <!-- Kotlin -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\hubspot.png" alt="Hub Spot">
          <p class="mt-3">Hub Spot</p>
        </div>
      </div>
      <!-- Firebase -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\spyfu.png" alt="Spy-Fu">
          <p class="mt-3">Spy-Fu</p>
        </div>
      </div>
      <!-- Angular UI -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\semrush.png" alt="Semrush">
          <p class="mt-3">Semrush</p>
        </div>
      </div>
      <!-- Swift -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\ads.webp" alt="Google Ads">
          <p class="mt-3">Google Ads</p>
        </div>
      </div>
      <!-- Onsen UI -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\wordstream.png" alt="Word Stream" style="width: 96px; height: 96px;">
          <p class="mt-3">Word Stream</p>
        </div>
      </div>
    </div>
  </div>
</section>



<!-- Second Section -->
<?php include 'blog-content.php' ?>
<!-- Font Awesome CDN -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

<?php include 'counter.php' ?>
<!-- Include Font Awesome if not already added -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">


<!-- Counter Animation Script -->
<script>
  const counters = document.querySelectorAll('.counter');
  counters.forEach(counter => {
    counter.innerText = '0';
    const updateCounter = () => {
      const target = +counter.getAttribute('data-target');
      const current = +counter.innerText;
      const increment = target / 200;

      if(current < target) {
        counter.innerText = `${Math.ceil(current + increment)}`;
        setTimeout(updateCounter, 10);
      } else {
        counter.innerText = target;
      }
    };
    updateCounter();
  });
</script>



<section class="py-5 bg" style="background-color: white;">
  <div class="container d-flex align-items-center flex-wrap">
    <!-- Left: Illustration -->
    <div class="col-lg-6 mb-4 mb-lg-0 text-center">
      <img src="assets\img\gads2.webp" alt="Illustration" class="img-fluid illustration-animation" style="max-width: 100%;">
    </div>

    <!-- Right: Content -->
    <div class="col-lg-6">
      <h2 class="fw-bold mb-3">Your Growth, Powered by Google Ads</h2>
      <p class="mb-4">
        We craft high-impact campaigns that put your brand in front of the right eyes at the right time. With certified experts and data-driven strategies, we turn every click into an opportunity and every ad into measurable success. Let your business lead where others follow.
     </p>
      <a href="contact" class="btn btn-primary" style="background-color: #1e3974;">Get Started</a>
    </div>
  </div>
</section>

<!-- Optional Animation -->

<?php include 'flag.php' ?>
 <!-- Start Faq Area
    ============================================= -->
    <div class="faq-area bg-gray default-padding" >
        <!-- Shape -->
        <div class="faq-sahpe">
            <img src="assets/img/illustration/faq1.png" alt="Image Not Found">
            <img src="assets/img/illustration/faq2.png" alt="Image Not Found">
        </div>
        <!-- End Shape -->
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4 class="sub-title">FAQ's</h4>
                        <h2 class="title">Frequently Asked Questions </h2>
                        <div class="devider"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 faq-style-one">

                    <div class="accordion" id="faqAccordion">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                               What is Google Ads and how can it help my business?

                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                    Google Ads is an online advertising platform that allows businesses to show up at the top of a search result. Our Google Ads service will get you there faster, target the right customers and increase quality traffic and conversions.


                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                What’s the difference between Google Ads and SEO?

                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                    Google Ads (part of SEM) allows you to be found offline by a potential customer instantly by utilizing paid ads, while SEO is a process that focuses on organic rankings over time. Our SEM services allows you to generate leads as we are developing your long-term SEO strategy.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                How much does Google Ads management cost?

                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                    Google Ads management is customized based on your goals, competition, and ad spend. We offer various packages to provide you with the best ROI on your PPC campaigns.

                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFour">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                Why hire a professional Google Ads agency vs. managing our ads ourselves?

                                </button>
                            </h2>


                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                    A professional Google Ads company will make sure your campaigns are optimized, cut down on wasted ad spend, and maximize results with data-driven strategies, advanced tools, and monitoring.
                                    </p>
                                </div>
                            </div>
                        </div>



                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFive">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                What types of Google Ads campaigns do you offer?

                                </button>
                            </h2>


                            <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                    We provide complete SEM services including Search Ads, Display Ads, Shopping Ads, Video Ads (YouTube), and Remarketing campaigns — tailored to meet your specific business needs.
                                    </p>
                                </div>
                            </div>
                        </div>


                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End Faq Area -->





    <?php include 'footer.php' ?>



    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/circle-progress.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/jquery.scrolla.min.js"></script>
    <script src="assets/js/YTPlayer.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/validnavs.js"></script>
    <script src="assets/js/main.js"></script>

</body>

</html>