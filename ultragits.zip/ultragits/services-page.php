<!-- Start Services Area
    ============================================= -->
    <div class="services-style-two-area default-padding bottom-less relative" style="background-color: #1e3974;">
        <div class="curve-top angle">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" fill="#ffffff">
                <path d="M421.9,6.5c22.6-2.5,51.5,0.4,75.5,5.3c23.6,4.9,70.9,23.5,100.5,35.7c75.8,32.2,133.7,44.5,192.6,49.7c23.6,2.1,48.7,3.5,103.4-2.5c54.7-6,106.2-25.6,106.2-25.6V0H0v30.3c0,0,72,32.6,158.4,30.5c39.2-0.7,92.8-6.7,134-22.4c21.2-8.1,52.2-18.2,79.7-24.2C399.3,7.9,411.6,7.5,421.9,6.5z"></path>
            </svg>
        </div>
        <div class="shape-animation-up-down updown-animation">
            <img src="assets/img/rocket.png" alt="Image not found">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-light text-center">
                        <h4 class="sub-title">What we do</h4>
                        <h2 class="title">Our Service For You 😊</h2>
                        <div class="devider"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">

                <!-- Single Item -->
                <div class="col-xl-3 col-lg-6 col-md-6 services-style-two">
                    <div class="item">
                        <div class="shape">
                            <img src="assets/img/30.png" alt="Image Not Found">
                        </div>
                        <i class="flaticon-web-development"></i>
                        <h4><a href="app-development-in-chennai.php">Web Development</a></h4>
                        <p>
                            Facilisis leo vel fringilla estimar ullamcorper. Posuere urna nectar tincidunt praesent semper feugiat nibh sed. Non pulvinar neque.
                        </p>
                        <a class="btn-icon" href="app-development-in-chennai.php">Know More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>


                <!-- Single Item -->
                <!-- Single Item -->
                <div class="col-xl-3 col-lg-6 col-md-6 services-style-two">
                    <div class="item">
                        <div class="shape">
                            <img src="assets/img/30.png" alt="Image Not Found">
                        </div>
                        <i class="flaticon-smartphone"></i>
                        <h4><a href="service-details.php">Mobile App Development
</a></h4>
                        <p>
                            Facilisis leo vel fringilla estimar ullamcorper. Posuere urna nectar tincidunt praesent semper feugiat nibh sed. Non pulvinar neque.
                        </p>
                        <a class="btn-icon" href="app-development-in-chennai.php">Know More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
                <!-- Single Item -->
                <!-- Single Item -->
                <div class="col-xl-3 col-lg-6 col-md-6 services-style-two">
                    <div class="item">
                        <div class="shape">
                            <img src="assets/img/30.png" alt="Image Not Found">
                        </div>
                        <i class="flaticon-coding"></i>
                        <h4><a href="app-development-in-chennai.php">Software Development </a></h4>
                        <p>
                            Facilisis leo vel fringilla estimar ullamcorper. Posuere urna nectar tincidunt praesent semper feugiat nibh sed. Non pulvinar neque.
                        </p>
                        <a class="btn-icon" href="app-development-in-chennai.php">Know More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>



                <div class="col-xl-3 col-lg-6 col-md-6 services-style-two">
                    <div class="item">
                        <div class="shape">
                            <img src="assets/img/30.png" alt="Image Not Found">
                        </div>
                        <i class="flaticon-resume"></i>
                        <h4><a href="flaticon-digital-marketing">Digital Marketing </a></h4>
                        <p>
                            Facilisis leo vel fringilla estimar ullamcorper. Posuere urna nectar tincidunt praesent semper feugiat nibh sed. Non pulvinar neque.
                        </p>
                        <a class="btn-icon" href="app-development-in-chennai.php">Know More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>


                <div class="col-xl-3 col-lg-6 col-md-6 services-style-two">
                    <div class="item">
                        <div class="shape">
                            <img src="assets/img/30.png" alt="Image Not Found">
                        </div>
                        <i class="fas fa-paint-brush"></i>
                        <h4><a href="app-development-in-chennai.php">Graphic Design </a></h4>
                        <p>
                            Facilisis leo vel fringilla estimar ullamcorper. Posuere urna nectar tincidunt praesent semper feugiat nibh sed. Non pulvinar neque.
                        </p>
                        <a class="btn-icon" href="app-development-in-chennai.php">Know More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>


                <div class="col-xl-3 col-lg-6 col-md-6 services-style-two">
                    <div class="item">
                        <div class="shape">
                            <img src="assets/img/30.png" alt="Image Not Found">
                        </div>
                        <i class="fas fa-cogs"></i>
                        <h4><a href="contact-us.php">ERP Software Development </a></h4>
                        <p>
                            Facilisis leo vel fringilla estimar ullamcorper. Posuere urna nectar tincidunt praesent semper feugiat nibh sed. Non pulvinar neque.
                        </p>
                        <a class="btn-icon" href="contact-us.php">Know More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>



                <div class="col-xl-3 col-lg-6 col-md-6 services-style-two">
                    <div class="item">
                        <div class="shape">
                            <img src="assets/img/30.png" alt="Image Not Found">
                        </div>
                        <i class="fas fa-server"></i>
                        <h4><a href="contact-us.php">Domain Registration & Web Hosting </a></h4>
                        <p>
                            Facilisis leo vel fringilla estimar ullamcorper. Posuere urna nectar tincidunt praesent semper feugiat nibh sed. Non pulvinar neque.
                        </p>
                        <a class="btn-icon" href="contact-us.php">Know More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
                <!-- Single Item -->
                <!-- Single Item -->
                <div class="col-xl-3 col-lg-6 col-md-6 services-style-two">
                    <div class="item">
                        <div class="shape">
                            <img src="assets/img/30.png" alt="Image Not Found">
                        </div>
                        <i class="fas fa-layer-group"></i>
                        <h4><a href="contact-us.php">Hybrid App Development
</a></h4>
                        <p>
                            Facilisis leo vel fringilla estimar ullamcorper. Posuere urna nectar tincidunt praesent semper feugiat nibh sed. Non pulvinar neque.
                        </p>
                        <a class="btn-icon" href="services-details.html">Know More <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>


                <!-- Single Item -->

            </div>
        </div>
    </div>
    <!-- End Services Area -->
