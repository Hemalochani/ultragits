<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Digalu - Digital Marketing Agency Template">

    <!-- ========== Page Title ========== -->
    <title>Best CMS Website Development Company in Chennai | UltraGITS</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="https://www.ultragits.com/assets/img/favicon.png" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/elegant-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon-set.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/validnavs.css" rel="stylesheet">
    <link href="assets/css/helper.css" rel="stylesheet">
    <link href="assets/css/unit-test.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <!-- ========== End Stylesheet ========== -->

    <style>
        .hero-section {

            display: flex;
            align-items: center;
            background-color: #f8f9fa;
        }


        .hero-text ul {
            list-style: none;
            padding: 0;
        }

        .hero-text ul li::before {
            content: "✔";
            color: black;
            margin-right: 10px;
        }





@keyframes bounce {
  0%, 20%, 50%, 80%, 100% {
    transform: translateY(0);
  }
  40% {
    transform: translateY(-15px);
  }
  60% {
    transform: translateY(-7px);
  }
}

.icon-animate {
  animation: bounce 2s infinite;
}

/* Extra purple color */
.text-purple {
  color: #6f42c1;
}
p{
    color: black;
     font-size: 18px;

}


.service-card {
  border: none;
  border-radius: 15px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.1);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.service-card:hover {
  transform: translateY(-10px);
  box-shadow: 0 10px 30px rgba(0,0,0,0.2);
}
.icon-wrapper {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto;
  color: #fff;
  font-size: 2rem;
  animation: bounce 2s infinite;
}

/* Bounce animation */
@keyframes bounce {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-10px);
  }
}


.tech-icon {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  padding: 10px;
}
.tech-icon img {
  width: 96px;
  height: 96px;
  animation: float 3s ease-in-out infinite;
}
.tech-icon:hover {
  transform: scale(1.1) rotate(5deg);
}
@keyframes float {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

.animated-icon {
  animation: bounce 2s infinite;
}

@keyframes bounce {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

.counter-box {
  transition: transform 0.3s ease;
}
.counter-box:hover {
  transform: translateY(-5px);
}


.icon-box {
  display: flex;
  flex-direction: column;
  align-items: center;
  animation: zoomIn 2s ease-in-out infinite alternate;
}
.flag-img {
  width: 100px;
  height: auto;
  border-radius: 8px;
  transition: transform 0.5s;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}
.flag-img:hover {
  transform: scale(1.1) rotate(5deg);
}
@keyframes zoomIn {
  from {
    transform: scale(1);
  }
  to {
    transform: scale(1.05);
  }
}


.card-category {
    position: absolute;
    top: 15px;
    right: 15px;
    background-color: #5c768d;
    color: white;
    padding: 5px 15px;
    font-weight: bold;
    text-transform: uppercase;
    font-size: 14px;
    border-radius: 20px;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
}

/* Card Body Styling */
.custom-card .card-body {
    padding: 20px;
}

.card-title {
    font-size: 19px;
    font-weight: bold;

}

.card-text {
    font-size: 18px;
    color: #555;
    margin-bottom: 15px;
}
.custom-card {
    position: relative;
    border: none;
    border-radius: 12px;  /* Rounded corners */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.custom-card:hover {
    transform: translateY(-10px); /* Card lifts on hover */
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2); /* Larger shadow on hover */
}

/* Image Styling: Ensures all images are the same size */
.custom-card img {
    width: 100%; /* Ensure the image takes the full width of the card */
    height: 250px; /* Fixed height for uniformity */
    object-fit: cover; /* Ensures images cover the area without stretching */
}




    </style>
</head>

<body>



    <!-- Header
    ============================================= -->
    <header>
        <?php include 'header.php' ?>


    </header>
    <!-- End Header -->

<!-- Start Breadcrumb
    ============================================= -->
    <div class="breadcrumb-area text-center bg-gray" style="background-image: url(assets/img/shape/breadcrumb.png); background-color:#e6e6e6;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1> Custom CMS Website Development Company in Chennai</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                            <li class="active">Custom CMS Website Development Company</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->


    <section class="hero-section container-fluid">
        <div class="row w-100 align-items-center">
            <div class="col-lg-6 text-center mb-4 mb-lg-0">
                <img src="assets\img\cms1.png" alt="Business Illustration" class="img-fluid">
            </div>
            <div class="col-lg-6 hero-text px-4"><br>
                <h2><strong>Custom CMS Website Development Company in Chennai</strong></h2>
                <p align="justify">Are you looking for the best (Content Management System) <b>CMS website development company in Chennai?</b>We at UltraGITS have expert developers who have industry experience in developing fast, secure & user-friendly websites for our clients. In the digital age, businesses need websites that not just look good but also easy to manage, update, and scale. Whether you're a startup or an enterprise, our <b>CMS website development service in Chennai</b> helps you to manage content effortlessly—without the need of technical skills. We are a chennai based CMS web development company specialize in a wide range of development like static, dynamic & e-commerce and deliver mobile friendly CMS websites at affordable price. From cms website development to maintenance, you’ll get full support from our team at UltraGITS.
</p>


            </div>
        </div>
    </section>


    <br>
<section class="py-5">
  <div class="container text-center">
    <h2 class="mb-5"><strong>Why Choose UltraGITS for Custom CMS Website Development Company in Chennai? </strong></h2>
    <div class="row mb-4">
      <!-- Benefit 1 -->
      <div class="col-md-4">
        <div class="p-4">
          <i class="fas fa-briefcase fa-2x mb-3 text-primary icon-animate"></i>
    <h5><strong>20+ years of experience in CMS</strong></h5>
          <p>We provide top-quality service with a focus on customer satisfaction and excellence.</p>
        </div>
      </div>

      
      <!-- Benefit 2 -->
      <div class="col-md-4">
        <div class="p-4">
          <i class="fas fa-lock fa-2x mb-3 text-success icon-animate"></i>
    <h5><strong>Secure CMS web development</strong></h5>
          <p>Our solutions are secure and trusted by thousands of happy clients nationwide.</p>
        </div>
      </div>
      <!-- Benefit 3 -->
      <div class="col-md-4">
        <div class="p-4">
         <i class="fas fa-globe fa-2x mb-3 text-info icon-animate"></i>
    <h5><strong>200+ website developed Internationally</strong></h5>
          <p>We offer 24/7 customer support to assist you with any queries or issues you may face.</p>
        </div>
      </div>
    </div>

    <div class="row">
      <!-- Benefit 4 -->
      <div class="col-md-4">
        <div class="p-4">
          <i class="fas fa-star fa-2x mb-3 text-warning icon-animate"></i>
    <h5><strong> Best CMS website development service in Chennai</strong></h5>
          <p>Our team ensures quick delivery to meet your tight deadlines efficiently.</p>
        </div>
      </div>
      <!-- Benefit 5 -->
      <div class="col-md-4">
        <div class="p-4">
         <i class="fas fa-clock fa-2x mb-3 text-danger icon-animate"></i>
    <h5><strong>Timely project delivery before the deadline</strong></h5>
          <p>We provide modern and innovative solutions that drive your business forward.</p>
        </div>
      </div>
      <!-- Benefit 6 -->
      <div class="col-md-4">
        <div class="p-4">
         <i class="fas fa-tools fa-2x mb-3 text-secondary icon-animate"></i>
    <h5><strong>Fast CMS website maintenance and support</strong></h5>
          <p>Our skilled professionals bring deep expertise and experience to every project.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Include Font Awesome CDN (if not already included) -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

<!-- Custom animation + extra color -->



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>



    <section class="py-5" style="background-color: #f8f9fa;">
  <div class="container text-center">
    <h2 class="mb-5" ><strong>Our Custom CMS Website Development Services</strong></h2>
    <div class="row mb-4">
      <!-- Service 1 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper bg-primary mb-4">
            <i class="fab fa-wordpress mb-3" style="color: #ffffff; font-size: 2rem;"></i>
            </div>
            <h3 class="card-title"><b>Wordpress Development Service</b></h3>
            <p class="card-text">We build custom mobile apps tailored to your business needs, ensuring high performance.</p>
          </div>
        </div>
      </div>
      <!-- Service 2 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper bg-success mb-4">
              <i class="fab fa-joomla mb-3" style="color: #ffffff; font-size: 2rem;"></i>
            </div>
            <h5 class="card-title"><b>Joomla Development</b></h5>
            <p class="card-text">Our cross-platform apps run smoothly on both Android and iOS with one codebase.</p>
          </div>
        </div>
      </div>
      <!-- Service 3 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper bg-warning mb-4">
            <i class="fab fa-drupal mb-3" style="color: #ffffff; font-size: 2rem;"></i>
            </div>
            <h5 class="card-title"><b>Drupal Development</b></h5>
            <p class="card-text">Beautiful, user-focused design that enhances user engagement and experience.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <!-- Service 4 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper">
              <img src="assets\img\Wix_logo.webp" alt="Wix Development">
            </div>
            <h5 class="card-title"><b>Wix Development</b></h5>
            <p class="card-text">We ensure your app’s data is fully protected with advanced security measures.</p>
          </div>
        </div>
      </div>
      <!-- Service 5 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper">
              <img src="assets\img\shopify.png" alt="Shopify Development">
            </div>
            <h5 class="card-title"><b>Shopify Development</b></h5>
            <p class="card-text">We integrate cloud solutions for real-time sync and powerful backend systems.</p>
          </div>
        </div>
      </div>
      <!-- Service 6 -->
      <div class="col-md-4 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            <div class="icon-wrapper">
              <img src="assets\img\Blogger-logo.png" alt="Blogger Development">
            </div>
            <h5 class="card-title"><b>Blogger Development</b></h5>
            <p class="card-text">Ongoing support and updates to keep your app running smoothly at all times.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



<section class="hero-section container-fluid" style="background-color: white;">
        <div class="row w-100 align-items-center">
            <div class="col-lg-6 text-center mb-4 mb-lg-0">
                <img src="assets\img\cms2.png" alt="Business Illustration" class="img-fluid">
            </div>
            <div class="col-lg-6 hero-text px-4"><br>
                <h2><strong>Our Expertise in CMS Website Development
</strong></h2>
                <p align="justify">We are focused on providing end-to-end CMS website design and development support to our clients. We have developed more than 500+ websites in Chennai and 200+ globally in various countries like USA, UAE, UK, Canada, Germany etc. Our team of Developers, UI/UX Designers, Testers all work as a team to develop a fully functional website which suits your unique business needs. A one custom CMS website solution can significantly skyrocket your business profit multiple times, through improved content control, Brand awareness in online, improved user experience, increase engagement and conversions, which increase your ROI. As a professional CMS website development company in Chennai, we give you open communication, no hidden cost and affordable pricing plans to satisfy your all website needs.
</p>



            </div>
        </div>
    </section>



<div class="container text-center">
  <h2 class="mb-5"><strong>What Makes UltraGITS Unique from Other CMS Agencies in Chennai?</strong></h2>

  <div class="row mb-4">
    <!-- Service 1 -->
    <div class="col-md-6 mb-4">
      <div class="card service-card h-100">
        <div class="card-body">
          <div class="icon-wrapper bg-primary mb-4">
            <i class="fas fa-tags mb-3" style="color: #ffffff; font-size: 2rem;"></i>
          </div>
          <h3 class="card-title"><b>Smart Pricing for Every Business</b></h3>
          <p class="card-text">We have pricing plans that will accommodate your budget and meet all quality standards. No hidden charges and no template buying charges, you’ll be charged only for the service & development aspects.</p>
        </div>
      </div>
    </div>

    <!-- Service 2 -->
    <div class="col-md-6 mb-4">
      <div class="card service-card h-100">
        <div class="card-body">
          <div class="icon-wrapper bg-warning mb-4">
            <i class="fas fa-pencil-ruler mb-3" style="color: #ffffff; font-size: 2rem;"></i>
          </div>
          <h5 class="card-title"><b>100% Custom-Built Websites - No Template</b></h5>
          <p class="card-text">Why do you need to select the template? when you have a chance to develop a unique one for your business. Our developers create a website from scratch to be the website unique and suits your business. If you like to continue with the templates, we have more than 1000+ reference to help you.</p>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <!-- Service 3 -->
    <div class="col-md-6 mb-4">
      <div class="card service-card h-100">
        <div class="card-body">
          <div class="icon-wrapper bg-danger mb-4">
            <i class="fas fa-users mb-3" style="color: #ffffff; font-size: 2rem;"></i>
          </div>
          <h5 class="card-title"><b>Dedicated team for each client</b></h5>
          <p class="card-text">We provide a dedicated team of developers, designers, testers and project managers who will regularly update about the ongoing work and respond quickly to the client request & feedback.</p>
        </div>
      </div>
    </div>

    <!-- Service 4-->
    <div class="col-md-6 mb-4">
      <div class="card service-card h-100">
        <div class="card-body">
          <div class="icon-wrapper bg-info mb-4">
            <i class="fas fa-headset mb-3" style="color: #ffffff; font-size: 2rem;"></i>
          </div>
          <h5 class="card-title"><b>Support after Hand Over</b></h5>
          <p class="card-text">We don’t deliver and run; we provide CMS website maintenance and support, updates, security patches, performance optimization, and upgrades regarding our client requirements.</p>
        </div>
      </div>
    </div>
  </div>
</div>



 <section class="container py-5">
    <div class="row justify-content-center">
        <!-- Left Column (Text Content) -->
        <div class="col-lg-6">
            <h2 class="mb-4 fw-bold text-dark">
                Benefits of Choosing UltraGITS for Custom CMS Website Development
            </h2>
            <ul class="list-unstyled fs-5 text-dark">
                <li class="mb-3">✅ In-house experts for WordPress, Joomla, Droopal, Wix</li>
                <li class="mb-3">✅ Dedicated team for development & contact support</li>
                <li class="mb-3">✅ Dedicated project manager for every client</li>
                <li class="mb-3">✅ Affordable packages along with premium packages</li>
                <li class="mb-3">✅ Fast-loading websites for improved user experience</li>
                <li class="mb-3">✅ Custom UI/UX designs each brand</li>
                <li class="mb-3">✅ Daily to weekly update about the website</li>
                <li class="mb-3">✅ Bug-free, clean-coded CMS development</li>
            </ul>
        </div>

        <!-- Right Column (Illustration Image) -->
        <div class="col-lg-6 text-center">
            <img src="assets\img\cms3.png" alt="SEO Illustration" class="img-fluid">
        </div>
    </div>
</section>



<section class="py-5" style="background-color: #f8f9fa;">
  <div class="container text-center">
    <h2 class="mb-5"><strong>Our Tools Expertise</strong></h2>
    <div class="row justify-content-center">
      <!-- Wordpress -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\wordpress.png" alt="Wordpress">
          <p class="mt-3">Wordpress</p>
        </div>
      </div>
      <!-- Joomla -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\joomla.webp" alt="Joomla">
          <p class="mt-3">Joomla</p>
        </div>
      </div>
      <!-- Drupal -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\drupal.png" alt="Drupal">
          <p class="mt-3">Drupal</p>
        </div>
      </div>
      <!-- Wix -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\Wix_logo.webp" alt="Wix">
          <p class="mt-3">Wix</p>
        </div>
      </div>
      <!-- Shopify -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\shopify.png" alt="Shopify">
          <p class="mt-3">Shopify</p>
        </div>
      </div>
      <!-- Blogger -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\Blogger-logo.png" alt="Blogger" style="width: 96px; height: 96px;">
          <p class="mt-3">Blogger</p>
        </div>
      </div>
    </div>
  </div>
</section>



<!-- Second Section -->
<?php include 'blog-content.php' ?>
<!-- Font Awesome CDN -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

<?php include 'counter.php' ?>
<!-- Include Font Awesome if not already added -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">


<!-- Counter Animation Script -->
<script>
  const counters = document.querySelectorAll('.counter');
  counters.forEach(counter => {
    counter.innerText = '0';
    const updateCounter = () => {
      const target = +counter.getAttribute('data-target');
      const current = +counter.innerText;
      const increment = target / 200;

      if(current < target) {
        counter.innerText = `${Math.ceil(current + increment)}`;
        setTimeout(updateCounter, 10);
      } else {
        counter.innerText = target;
      }
    };
    updateCounter();
  });
</script>



<section class="py-5 bg" style="background-color: white;">
  <div class="container d-flex align-items-center flex-wrap">
    <!-- Left: Illustration -->
    <div class="col-lg-6 mb-4 mb-lg-0 text-center">
      <img src="assets\img\cms.png" height="500" width="500" alt="Illustration" class="img-fluid illustration-animation" style="max-width: 100%;">
    </div>

    <!-- Right: Content -->
    <div class="col-lg-6">
      <h2 class="fw-bold mb-3">📞 Ready to Launch Your CMS Website?</h2>
      <p class="mb-4">
      Let UltraGITS turn your idea into a powerful, easy-to-manage website that grows with your business.
    </p>
      <a href="contact-us.php" class="btn btn-primary" style="background-color: #1e3974;">Get a free consultation today!</a>
    </div>
  </div>
</section>

<!-- Optional Animation -->

<?php include 'flag.php' ?>
 <!-- Start Faq Area
    ============================================= -->
    <div class="faq-area bg-gray default-padding" >
        <!-- Shape -->
        <div class="faq-sahpe">
            <img src="assets/img/illustration/faq1.png" alt="Image Not Found">
            <img src="assets/img/illustration/faq2.png" alt="Image Not Found">
        </div>
        <!-- End Shape -->
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4 class="sub-title">FAQ's</h4>
                        <h2 class="title">Frequently Asked Questions </h2>
                        <div class="devider"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 faq-style-one">

                    <div class="accordion" id="faqAccordion">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                               What CMS platforms do you use?

                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                    We normally work with WordPress, Joomla, Shopify and Magento, Wix, or even offer custom (CMS) solutions when necessary. Our developers prefer many suggestions & features of the CMS, you can select which one suits you.

                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Will my website look good on phones and tablets?

                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                    Yes, We build all sites responsive so whether a person is on a mobile, tablet, or desktop, they will have a consistent view and a clean fast experience which drives more conversion through the website.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                Can I make changes on the site without a developer?

                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                    Yes. This is actually the whole point of a CMS. You will be able to update text, images, blog posts and more without messing with any code. This will help you to take quick action without contacting any developers.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFour">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                               How long does it take to build a CMS website?

                                </button>
                            </h2>


                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                   It really depends on the level of complexity of the site. The majority of CMS projects take 2 to 6 months to complete. Our team updates on an ongoing basis and a dedicated manager will be available for you to update regularly.
                                    </p>
                                </div>
                            </div>
                        </div>



                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFive">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                Will you help me out after launch?
                                </button>
                            </h2>


                            <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                  Yes! We support ongoing development and maintenance, including fixing bugs, security, and managing the maintainability and features.  
                                  </p>
                                </div>
                            </div>
                        </div>





                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingSix">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                               Is the website going to be SEO-friendly?
                                </button>
                            </h2>


                            <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p>
                                    Yes, 100%.  We utilize proper SEO practices when we build the site - fast loading, mobile-friendly, clean code, solid site structure, and all the good stuff that search engines love.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End Faq Area -->





    <?php include 'footer.php' ?>



    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/circle-progress.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/jquery.scrolla.min.js"></script>
    <script src="assets/js/YTPlayer.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/validnavs.js"></script>
    <script src="assets/js/main.js"></script>

</body>

</html>